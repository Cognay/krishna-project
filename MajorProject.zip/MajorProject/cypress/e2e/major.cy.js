import { TravelInsurance } from "../pom/travelIncurance";
import { CarInsurance } from "../pom/carInsurance";
import { HealthInsuranceItems } from "../pom/healthInsuranceItems";

/// <reference types="cypress" />

Cypress.on('uncaught:exception', (err, runnable) => {
  return false;
});



describe('Major project',function(){
//Used fixture to get the data
    beforeEach(function(){
        cy.fixture('example').then(function(data){
            this.data = data;
        })
    })


    it("getting the travel insurance for the students",function(){

      //visiting the site
          TravelInsurance.Visitsite(this.data.url);

       //going inside the travel insurance
          TravelInsurance.insideTravelInc()

       //inside the travel insurance (Different Domain)

       //filling details
          
         TravelInsurance.fillingDetails(this.data.country,this.data.startDate,this.data.endDate,this.data.noOfTravellers,this.data.Age1Trav,this.data.Age2trav,this.data.choose)
        //fetching the polices
      
         TravelInsurance.cheapestPlans();

       })




    it("car insurance",function(){

        //visiting the site

         CarInsurance.VisitSite(this.data.url)


        //visiting the car insurance page

        CarInsurance.carInsurance();

        //filling car details (Different Domain)
        //Error message validation

        CarInsurance.carDetailsandErrorValidation(this.data.city,this.data.brand,this.data.carName,this.data.fuelType,this.data.carModel,this.data.name,this.data.number);

          

      })





      it('Health related all the menu items',function(){

         //visiting the site
         
           HealthInsuranceItems.VisitSite(this.data.url);


         //Getting All Health menus 

           HealthInsuranceItems.allItems("health-insurance");


      })

 


 })
