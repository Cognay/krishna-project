/// <reference types="cypress" />

Cypress.on('uncaught:exception', (err, runnable) => {
  return false;
});
describe('Major project', () => {
    it.only("getting the travel insurance for the students",()=>{

      ////////////////////visiting the site////////////////////////////////
       cy.visit('http://policybazaar.com');

       //////////////////going inside the travel insurance////////////////
       cy.get(':nth-child(7) > a > .prd-icon > .shadowHandlerBox').click();

       ///////////////////inside the travel insurance/////////////////////

       ////////////////////////filling details///////////////////////////
       cy.origin('https://travel.policybazaar.com',()=>{
        cy.get('#country').click();
        cy.get('.search-item').contains('li','United Kingdom').click();
        cy.get('.selectedCountryWrap p:visible').should('have.length',1).and('contain','United Kingdom')
        
        cy.contains('button','Done').should('be.visible').click({force:true});

        cy.get('.newPq_modal__container').should('not.exist')

        cy.get('.newPq_duration_wrap > :nth-child(1)').click();

        // cy.contains('button','Explore Plans').should('be.visible').click();
        cy.get('.MuiPickersDay-dayLabel').contains('19').should('be.visible').click({force:true});
        cy.get('.MuiPickersDay-dayLabel').contains('23').should('be.visible').click({force:true});

        // cy.contains('span','23').should('be.visible').click();
        
        cy.contains('button',/Continue|Done/).should('be.visible').click();

        cy.contains('label','2').click();

        cy.get('.customDropdown__select').eq(0).click();

        cy.contains('div','20 years').click();

        cy.get('.customDropdown__select').eq(1).click();

        cy.contains('div','21 years').click();

        cy.contains('label','No').click();

        cy.contains('button','Done').should('be.visible').click();

        cy.get('.newPq_modal__container').should('not.exist');

        cy.contains('button','Explore Plan').should('be.visible').click();


        //----------------------------------------------fetching the polices--------------------------------->
      
      const plans = [];

      cy.get('.quotesCardWrapper').each(($el) => {
      const title = $el.find('.quotesCard--insurerName').text().trim();

      let premiumText = $el.find('.premiumPlanPrice').first().text().trim();
  
      premiumText = premiumText.replace(/[^0-9.]/g, '');

      const premium = parseFloat(premiumText);

      plans.push({
        title:title,
        premium:premium
      })

      }).then(()=>{
          plans.sort((a,b)=> a.premium - b.premium);

          const cheapestThree = plans.slice(0,3);

          cy.log("3 Cheapest Plans :");

          cheapestThree.forEach((plan,ind)=>{
             cy.log(`${ind+1}---->${plan.title} with premium ${plan.premium}`);
          })
      });


        //-----------------------------------------------------------------------------------------------//

        // cy.contains('a','Add').should('be.visible').click({force:true});
        
        // cy.contains('div','Select age of traveller 1').click();
        
        // cy.contains('button','Done').should('be.visible').click();

        // cy.get('.newPq_modal__container').should('not.exist')

        // cy.contains('button','Continue').should('be.visible').click();

       })

       
    })



    it("car insurance",()=>{

         cy.visit('http://policybazaar.com');

         cy.get('.car > a > .prd-icon > .shadowHandlerBox').click();


         cy.origin("https://ci.policybazaar.com/",()=>{

          //----------------error message without the car number--------------------// 
           
          cy.get(".CarRegDetails_carRegForm__Iqhdb button").should('have.text',"View Prices ").click();

          cy.get('.redText').should('have.text','Please enter a valid car number');

          //---------------------------------------------------------------------

          cy.get('.CarRegDetails_blueTextButton__P1blP').click()
 
          //------------------------------------------------------------------filling Car details

          cy.contains('ul li','Noida').click();

          cy.get('.headingV3').should('have.text','Select Car Brand');

          cy.contains('ul li','HONDA').click();

          cy.get('.headingV3').should('have.text','Select Car Model');

          cy.contains('ul li','CITY').click();

          cy.get('.headingV3').should('have.text','Select Car Fuel Type');

          cy.contains('ul li','Petrol').click();

          cy.get('.headingV3').should('have.text',"Select Car Variant");

          cy.contains('ul li','1.5 V Petrol (1498 cc)').click();

          cy.get('.headingV3').should('have.text',"Almost done! Just one last step");


          //-----------------------------name and phoneno filling----------------------------------

          cy.get('#name-form-control').type('ABC');

          cy.get('#mobile-form-control').type('5674');

          cy.get('.errorMsg').should('have.text','Enter a valid mobile number');

         })

      })





      it('Health related all the menu items',()=>{

         let healthMenus = [];
         
           cy.visit('http://policybazaar.com');


          //  cy.get('.prd-block p').each(($el)=>{
          //     let item = $el.text().trim().replace('\n','')

          //     if(item.includes('Health' || 'Cancer' || 'Family Health' || 'Term Life')){
          //       healthMenus.push(item);
          //     }
          //  })
           
           
           
           cy.get('a[href*="health-insurance"]').each(($el)=>{
             healthMenus.push($el.text().trim());
           }).then(()=>{
            cy.log('The Health Menus')
            healthMenus.forEach((el,ind)=>{
              cy.log(`${ind+1}--->${el}`)
           })
           })

      })

 
})



