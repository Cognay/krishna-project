export const CarInsurance = {
    VisitSite(url){
        cy.visit(url);
    },

    carInsurance(){
        cy.get('.car > a > .prd-icon > .shadowHandlerBox').click();
    },

    carDetailsandErrorValidation(city,brand,carName,fuelType,carModel,name,number){
        const url = "https://ci.policybazaar.com";
         cy.origin(url,{args:{city,brand,carName,fuelType,carModel,name,number}},
            ({city,brand,carName,fuelType,carModel,name,number})=>{
           
          cy.get(".CarRegDetails_carRegForm__Iqhdb button").should('have.text',"View Prices ").click();

          cy.get('.redText').should('have.text','Please enter a valid car number');

          //---------------------------------------------------------------------

          cy.get('.CarRegDetails_blueTextButton__P1blP').click()
 
          //------------------------------------------------------------------filling Car details

          cy.contains('ul li',city).click();

          cy.get('.headingV3').should('have.text','Select Car Brand');

          cy.contains('ul li',brand).click();

          cy.get('.headingV3').should('have.text','Select Car Model');

          cy.contains('ul li',carName).click();

          cy.get('.headingV3').should('have.text','Select Car Fuel Type');

          cy.contains('ul li',fuelType).click();

          cy.get('.headingV3').should('have.text',"Select Car Variant");

          cy.contains('ul li',carModel).click();

          cy.get('.headingV3').should('have.text',"Almost done! Just one last step");


          //-----------------------------name and phoneno filling----------------------------------

          cy.get('#name-form-control').type(name);

          cy.get('#mobile-form-control').type(number);

          cy.get('.errorMsg').should('have.text','Enter a valid mobile number');

         })

    }
}