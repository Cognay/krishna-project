export const HealthInsuranceItems = {
    VisitSite(url){
        cy.visit(url);
    },

    allItems(context){
          let healthMenus = [];
           cy.get(`a[href*=${context}]`).each(($el)=>{
             healthMenus.push($el.text().trim());
           }).then(()=>{
            cy.log('The Health Menus')
            healthMenus.forEach((el,ind)=>{
              cy.log(`${ind+1}--->${el}`)
           })
           })
    }
}