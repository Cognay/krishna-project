export const TravelInsurance = {

    Visitsite(url){
        cy.visit(url);
    },





    insideTravelInc(){
       cy.get(':nth-child(7) > a > .prd-icon > .shadowHandlerBox').click();
    },






    fillingDetails(country,startDate,endDate,noOfTravellers,Age1Trav,Age2trav,choose){
        
         const url = 'https://travel.policybazaar.com';
        
         cy.origin(url,{args:{country,startDate,endDate,noOfTravellers,Age1Trav,Age2trav,choose}},(
          {country,startDate,endDate,noOfTravellers,Age1Trav,Age2trav,choose}
         )=>{

         cy.get('#country').click();
         cy.get('.search-item').contains('li',country).click();
         cy.get('.selectedCountryWrap p:visible').should('have.length',1).and('contain','United Kingdom')
        
         cy.contains('button','Done').should('be.visible').click({force:true});

         cy.get('.newPq_modal__container').should('not.exist')

         cy.get('.newPq_duration_wrap > :nth-child(1)').click();

         cy.get('.MuiPickersDay-dayLabel').contains(startDate).should('be.visible').click({force:true});
         cy.get('.MuiPickersDay-dayLabel').contains(endDate).should('be.visible').click({force:true});
        
         cy.contains('button',/Continue|Done/).should('be.visible').click();

         ///////
        //  cy.get('.newPq_travellers_wrap').click();
         ///////

         cy.contains('label',noOfTravellers).click();

         cy.get('.customDropdown__select').eq(0).click({force: true});

         cy.contains('div',Age1Trav).click();

         cy.get('.customDropdown__select').eq(1).click({force: true});

         cy.contains('div',Age2trav).click();

         cy.contains('label',choose).click();

         cy.contains('button','Done').should('be.visible').click();

         cy.get('.newPq_modal__container').should('not.exist');

         cy.contains('button','Explore Plan').should('be.visible').click();


     }
     )
    },


    

     cheapestPlans(){

      const url = 'https://travel.policybazaar.com';

        

      cy.origin(url,()=>{

        const plans = [];
            
      cy.get('.quotesCardWrapper').each(($el) => {
      const title = $el.find('.quotesCard--insurerName').text().trim();

      let premiumText = $el.find('.premiumPlanPrice').first().text().trim();
  
      premiumText = premiumText.replace(/[^0-9.]/g, '');

      const premium = parseFloat(premiumText);

      plans.push({
        title:title,
        premium:premium
      })

      }).then(()=>{
          plans.sort((a,b)=> a.premium - b.premium);

          const cheapestThree = plans.slice(0,3);

          cy.log("3 Cheapest Plans :");

          cheapestThree.forEach((plan,ind)=>{
             cy.log(`${ind+1}---->${plan.title} with premium ${plan.premium}`);
          })
      });



        })

      
     }


}